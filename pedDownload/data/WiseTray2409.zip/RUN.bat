@echo off

taskkill /f /im wisetray.exe >nul 2>&1
setlocal enabledelayedexpansion

REM Set debug_mode to 1 for debugging output, 0 to suppress
set "debug_mode=0"

echo Choose a new value for ShowTipS:
echo 1. Net Usage (2)
echo 2. CPU Usage (128)
echo 3. CPU Temperature (32)
echo 4. GPU Temperature (64)
echo 5. Hard Disk Temperature (8)


choice /c 12345 /n
set "new_value="

REM Set new_value based on the choice made
if errorlevel 5 set "new_value=8" & goto end_choice
if errorlevel 4 set "new_value=64" & goto end_choice
if errorlevel 3 set "new_value=32" & goto end_choice
if errorlevel 2 set "new_value=128" & goto end_choice
if errorlevel 1 set "new_value=2" & goto end_choice

:end_choice
REM Validate the new_value
if "%new_value%"=="" (
    echo Invalid choice.
    exit /b 1
)

if !debug_mode! == 1 (
    echo You selected: %new_value%
)

set "input_file=%~dp0config_tray.ini"  REM Ensure config_tray.ini is in the same directory
set "temp_file=%TEMP%\temp.ini"  REM Specify the path for temp.ini


REM Read the input file and update the ShowTipS value
(
    for /f "usebackq delims=" %%a in ("%input_file%") do (
        set "line=%%a"
        if !debug_mode! == 1 (
            echo Processing line: !line!  REM Debugging line
        )
        echo !line! | findstr /b "ShowTipS=" >nul
        if !errorlevel! == 0 (
            if !debug_mode! == 1 (
                echo Found ShowTipS, updating to: ShowTipS=!new_value!  REM Debugging line
            )
            echo ShowTipS=!new_value!
        ) else (
            REM Skip lines that are comments or empty
            if not "!line!"=="" (
                echo !line!
            )
        )
    )
) > "%temp_file%"

REM Check if temp_file is created and not empty
if exist "%temp_file%" (
    if !debug_mode! == 1 (
        echo Temp file created successfully.
        type "%temp_file%"  REM Display the contents of the temp file for debugging
    )
) else (
    echo Failed to create temp file.
)

REM Retry mechanism for moving the file
set "retry_count=0"
set "max_retries=5"
:retry
move /y "%temp_file%" "%input_file%"
if errorlevel 1 (
    set /a retry_count+=1
    if !retry_count! lss !max_retries! (
        echo File is in use, retrying in 1 second...
        timeout /t 1 >nul
        goto retry
    ) else (
        echo Failed to move file after !max_retries! attempts.
        exit /b 1
    )
)

if !debug_mode! == 1 (
    echo ShowTipS updated to %new_value% in %input_file%.
    pause
)

endlocal

REM Start WiseTray.exe from the directory where the batch file is located
start "" "%~dp0WiseTray.exe"  REM Start WiseTray.exe using the path of the batch file

REM 1 - net Usage
REM 2 - net Usage
REM 8 - DiskTemperature
REM 32 - CPU temperature
REM 64 - GPU Temperature
REM 128 - CPU Usage